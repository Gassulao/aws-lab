// Intérprete de Bash simplificado. Los comandos son funciones registradas; las estructuras de control, las
// expansiones, las tuberías y las redirecciones se resuelven aquí.
import type { CloudState } from '../engine/types';
import { parse, ParseError, type Node, type SimpleCmd, type Word } from './parser';
import { VFS, FsError } from './fs';
import { changed } from '../engine/store';

export interface CmdResult {
  out: string;
  err: string;
  code: number;
}

export interface Shell {
  s: CloudState;
  fs: VFS;
  /** Variables de la sesión (exportadas o no). */
  vars: Record<string, string>;
  cwd: string;
  lastCode: number;
  /** Salida de sustituciones de comando anidadas, para depurar. */
  depth: number;
  funcs: Record<string, never>;
}

export type CmdFn = (args: string[], io: { stdin: string; sh: Shell }) => CmdResult | Promise<CmdResult>;

const registry = new Map<string, CmdFn>();
export function registerCommand(name: string | string[], fn: CmdFn) {
  for (const n of Array.isArray(name) ? name : [name]) registry.set(n, fn);
}
export function hasCommand(name: string) {
  return registry.has(name);
}

export const ok = (out = ''): CmdResult => ({ out, err: '', code: 0 });
export const fail = (err: string, code = 1): CmdResult => ({ out: '', err: err.endsWith('\n') ? err : err + '\n', code });

export function newShell(s: CloudState): Shell {
  const sh: Shell = { s, fs: new VFS(s.fs), vars: {}, cwd: s.cli.cwd, lastCode: 0, depth: 0, funcs: {} };
  return sh;
}

function lookupVar(sh: Shell, name: string): string {
  if (name === '?') return String(sh.lastCode);
  if (name === '$') return '1';
  if (name === 'HOME') return sh.vars.HOME ?? `/home/${sh.s.me.userName}`;
  if (name === 'USER') return sh.vars.USER ?? sh.s.me.userName;
  if (name === 'PWD') return sh.cwd;
  // ${VAR:-default}
  const m = /^([A-Za-z_][A-Za-z0-9_]*):-(.*)$/.exec(name);
  if (m) return (sh.vars[m[1]] ?? sh.s.cli.env[m[1]]) || m[2];
  const m2 = /^#([A-Za-z_][A-Za-z0-9_]*)$/.exec(name);
  if (m2) return String((sh.vars[m2[1]] ?? '').length);
  return sh.vars[name] ?? sh.s.cli.env[name] ?? '';
}

async function expandWord(sh: Shell, w: Word): Promise<string[]> {
  // Devuelve una lista porque una expansión sin comillas puede dividirse en varias palabras.
  let fields: string[] = [''];
  let hasGlob = false;
  let raw = '';
  const addText = (txt: string, split: boolean) => {
    if (!split) {
      fields[fields.length - 1] += txt;
      raw += txt;
      return;
    }
    const pieces = txt.split(/\s+/);
    pieces.forEach((pc, i) => {
      if (i > 0) fields.push('');
      fields[fields.length - 1] += pc;
    });
    raw += txt;
  };
  for (const p of w.parts) {
    if (p.t === 'lit') {
      // ~ al inicio
      if (p.v.startsWith('~') && fields.length === 1 && fields[0] === '' && (p.v === '~' || p.v.startsWith('~/'))) addText(lookupVar(sh, 'HOME') + p.v.slice(1), false);
      else addText(p.v, false);
    } else if (p.t === 'var') addText(lookupVar(sh, p.name), !p.quoted);
    else if (p.t === 'cmd') {
      const r = await runString(sh, p.src, '', true);
      addText(r.out.replace(/\n+$/, ''), !p.quoted);
    } else {
      hasGlob = true;
      addText(p.v, false);
    }
  }
  if (!w.quoted && fields.length === 1 && fields[0] === '' && w.parts.every((p) => p.t === 'var' || p.t === 'cmd')) return [];
  if (hasGlob && !w.quoted) {
    const out: string[] = [];
    for (const f of fields) {
      const m = /[*?]/.test(f) ? sh.fs.glob(f, sh.cwd) : [];
      if (m.length) out.push(...m);
      else out.push(f);
    }
    return out;
  }
  if (!w.quoted) fields = fields.filter((f) => f !== '');
  return fields;
}

async function expandAll(sh: Shell, words: Word[]): Promise<string[]> {
  const out: string[] = [];
  for (const w of words) out.push(...(await expandWord(sh, w)));
  return out;
}

async function runSimple(sh: Shell, n: SimpleCmd, stdin: string): Promise<CmdResult> {
  const args = await expandAll(sh, n.words);
  // asignaciones
  const saved: Record<string, string | undefined> = {};
  for (const a of n.assigns) {
    const v = (await expandWord(sh, a.value)).join(' ');
    if (!args.length) {
      sh.vars[a.name] = v;
      sh.s.cli.env[a.name] = v;
    } else {
      saved[a.name] = sh.vars[a.name];
      sh.vars[a.name] = v;
    }
  }
  let input = stdin;
  if (n.heredoc) {
    input = n.heredoc.expand ? await expandHeredoc(sh, n.heredoc.body) : n.heredoc.body;
  }
  let res: CmdResult = { out: '', err: '', code: 0 };
  let outTarget: { path: string; append: boolean } | null = null;
  let errTarget: { path: string; append: boolean } | null = null;
  let errToOut = false;
  for (const r of n.redirects) {
    if (r.op === '2>&1') {
      errToOut = true;
      continue;
    }
    const target = (await expandWord(sh, r.target!)).join('');
    const abs = VFS.norm(target, sh.cwd);
    if (r.op === '<') {
      try {
        input = sh.fs.readFile(abs);
      } catch (e) {
        return fail(`bash: ${target}: ${(e as Error).message}`);
      }
    } else if (r.op === '>' || r.op === '>>' || r.op === '&>') {
      outTarget = { path: abs, append: r.op === '>>' };
      if (r.op === '&>') errToOut = true;
    } else errTarget = { path: abs, append: r.op === '2>>' };
  }
  if (args.length) {
    const [name, ...rest] = args;
    const fn = registry.get(name);
    if (!fn) res = fail(`bash: ${name}: command not found`, 127);
    else {
      try {
        res = await fn(rest, { stdin: input, sh });
      } catch (e) {
        res = fail(`${name}: ${(e as Error).message}`);
      }
    }
  }
  for (const [k, v] of Object.entries(saved)) {
    if (v === undefined) delete sh.vars[k];
    else sh.vars[k] = v;
  }
  try {
    if (errToOut) {
      res = { out: res.out + res.err, err: '', code: res.code };
    }
    if (errTarget) {
      sh.fs.writeFile(errTarget.path, res.err, errTarget.append);
      res = { ...res, err: '' };
    }
    if (outTarget) {
      if (outTarget.path === '/dev/null') res = { ...res, out: '' };
      else {
        sh.fs.writeFile(outTarget.path, res.out, outTarget.append);
        res = { ...res, out: '' };
      }
    }
  } catch (e) {
    const msg = e instanceof FsError ? e.message : String(e);
    return fail(`bash: ${(outTarget ?? errTarget)!.path}: ${msg}`);
  }
  return res;
}

async function expandHeredoc(sh: Shell, body: string): Promise<string> {
  let out = '';
  let i = 0;
  while (i < body.length) {
    if (body[i] === '$') {
      const m = /^\$\{([^}]+)\}|^\$([A-Za-z_][A-Za-z0-9_]*)/.exec(body.slice(i));
      if (m) {
        out += lookupVar(sh, m[1] ?? m[2]);
        i += m[0].length;
        continue;
      }
      if (body[i + 1] === '(') {
        let d = 1;
        let j = i + 2;
        while (j < body.length && d) {
          if (body[j] === '(') d++;
          else if (body[j] === ')') d--;
          j++;
        }
        out += (await runString(sh, body.slice(i + 2, j - 1), '', true)).out.replace(/\n+$/, '');
        i = j;
        continue;
      }
    }
    out += body[i++];
  }
  return out;
}

async function run(sh: Shell, n: Node, stdin: string): Promise<CmdResult> {
  switch (n.type) {
    case 'simple': {
      const r = await runSimple(sh, n, stdin);
      sh.lastCode = r.code;
      return r;
    }
    case 'pipeline': {
      let data = stdin;
      let err = '';
      let last: CmdResult = ok();
      for (const c of n.cmds) {
        last = await run(sh, c, data);
        err += last.err;
        data = last.out;
      }
      const code = n.negate ? (last.code === 0 ? 1 : 0) : last.code;
      sh.lastCode = code;
      return { out: last.out, err, code };
    }
    case 'andor': {
      let r = await run(sh, n.first, stdin);
      let out = r.out;
      let err = r.err;
      for (const step of n.rest) {
        if (step.op === '&&' ? r.code === 0 : r.code !== 0) {
          r = await run(sh, step.node, stdin);
          out += r.out;
          err += r.err;
        }
      }
      return { out, err, code: r.code };
    }
    case 'list': {
      let out = '';
      let err = '';
      let code = 0;
      for (const it of n.items) {
        const r = await run(sh, it, stdin);
        out += r.out;
        err += r.err;
        code = r.code;
      }
      return { out, err, code };
    }
    case 'if': {
      const c = await run(sh, n.cond, stdin);
      const branch = c.code === 0 ? n.then : n.else;
      const r = branch ? await run(sh, branch, stdin) : ok();
      return { out: c.out + r.out, err: c.err + r.err, code: r.code };
    }
    case 'for': {
      const items = await expandAll(sh, n.words);
      let out = '';
      let err = '';
      let code = 0;
      for (const it of items) {
        sh.vars[n.name] = it;
        const r = await run(sh, n.body, stdin);
        out += r.out;
        err += r.err;
        code = r.code;
      }
      return { out, err, code };
    }
    case 'while': {
      let out = '';
      let err = '';
      let code = 0;
      for (let guard = 0; guard < 1000; guard++) {
        const c = await run(sh, n.cond, stdin);
        out += c.out;
        err += c.err;
        if (c.code !== 0) break;
        const r = await run(sh, n.body, stdin);
        out += r.out;
        err += r.err;
        code = r.code;
      }
      return { out, err, code };
    }
  }
}

export async function runString(sh: Shell, src: string, stdin = '', nested = false): Promise<CmdResult> {
  let ast: Node;
  try {
    ast = parse(src);
  } catch (e) {
    if (e instanceof ParseError) return fail(`bash: ${e.message}`, 2);
    throw e;
  }
  if (nested) sh.depth++;
  try {
    const r = await run(sh, ast, stdin);
    return r;
  } finally {
    if (nested) sh.depth--;
  }
}

/** Ejecuta una línea escrita por el usuario y la anota en el registro de comandos (para validar laboratorios). */
export async function execLine(sh: Shell, line: string, source: 'typed' | 'shell' | 'console' = 'typed'): Promise<CmdResult> {
  const r = await runString(sh, line);
  sh.s.cli.cwd = sh.cwd;
  sh.s.cli.history.push(line);
  sh.s.cli.commandLog.push({ ts: Date.now(), cmd: line, ok: r.code === 0, source });
  changed(); // avisa a la interfaz y guarda el estado
  return r;
}
