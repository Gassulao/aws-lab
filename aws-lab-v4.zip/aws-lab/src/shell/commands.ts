// Comandos de Linux disponibles en la terminal simulada.
import { registerCommand, ok, fail, runString, type Shell, type CmdResult } from './interp';
import { VFS } from './fs';
import { now } from '../engine/util';
import { jq as runJq, JqError } from './jq';
import { anonymousGet } from '../engine/services/s3';
import { presignedGet } from '../engine/services/s3Extra';
import { webGet } from '../engine/services/web';

const abs = (sh: Shell, p: string) => VFS.norm(p, sh.cwd);

function readInputs(sh: Shell, files: string[], stdin: string): { text: string } | { err: string } {
  if (!files.length) return { text: stdin };
  let text = '';
  for (const f of files) {
    try {
      text += sh.fs.readFile(abs(sh, f));
    } catch (e) {
      return { err: `${f}: ${(e as Error).message}` };
    }
  }
  return { text };
}

function splitFlags(args: string[]): { flags: Set<string>; vals: Record<string, string>; rest: string[] } {
  const flags = new Set<string>();
  const vals: Record<string, string> = {};
  const rest: string[] = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--') {
      rest.push(...args.slice(i + 1));
      break;
    }
    if (a.startsWith('--')) flags.add(a.slice(2));
    else if (a.startsWith('-') && a.length > 1 && !/^-\d/.test(a)) for (const c of a.slice(1)) flags.add(c);
    else rest.push(a);
  }
  return { flags, vals, rest };
}

registerCommand('echo', (args) => {
  let nl = true;
  let esc = false;
  const a = [...args];
  while (a[0] === '-n' || a[0] === '-e') {
    if (a[0] === '-n') nl = false;
    else esc = true;
    a.shift();
  }
  let s = a.join(' ');
  if (esc) s = s.replace(/\\n/g, '\n').replace(/\\t/g, '\t');
  return ok(s + (nl ? '\n' : ''));
});

registerCommand('printf', (args) => {
  const [fmt = '', ...vals] = args;
  let i = 0;
  const out = fmt.replace(/%[sdq%]|\\n|\\t/g, (m) => (m === '\\n' ? '\n' : m === '\\t' ? '\t' : m === '%%' ? '%' : (vals[i++] ?? '')));
  return ok(out);
});

registerCommand('pwd', (_a, { sh }) => ok(sh.cwd + '\n'));
registerCommand('whoami', (_a, { sh }) => ok(sh.s.me.userName + '\n'));
registerCommand('hostname', () => ok('aws-lab\n'));
registerCommand('uname', (a) => ok(a.includes('-a') ? 'Linux aws-lab 6.1.0 #1 SMP x86_64 GNU/Linux\n' : 'Linux\n'));
registerCommand('clear', () => ok(''));
registerCommand('true', () => ok());
registerCommand('false', () => ({ out: '', err: '', code: 1 }));
registerCommand('exit', (a) => ({ out: '', err: '', code: Number(a[0] ?? 0) }));
registerCommand('sleep', () => ok());
const UNIT_MS: Record<string, number> = { second: 1000, sec: 1000, minute: 60_000, min: 60_000, hour: 3_600_000, day: 86_400_000, week: 604_800_000 };
/** Interpreta la parte útil de `date -d`: now, @epoch, "N unidades ago", "+N unidades"/"-N unidades" e ISO 8601. */
function parseDateArg(spec: string, base: number): number | null {
  const t = spec.trim();
  if (!t || t === 'now') return base;
  if (t === 'yesterday') return base - 86_400_000;
  if (t === 'tomorrow') return base + 86_400_000;
  const ep = t.match(/^@(-?\d+)$/);
  if (ep) return Number(ep[1]) * 1000;
  const rel = t.match(/^([+-]?\d+)\s*(second|sec|minute|min|hour|day|week)s?(\s+ago)?$/i);
  if (rel) return base + Number(rel[1]) * UNIT_MS[rel[2].toLowerCase()] * (rel[3] ? -1 : 1);
  const v = Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(t) ? t : t.replace(' ', 'T') + 'Z');
  return Number.isNaN(v) ? null : v;
}
function strftime(fmt: string, ms: number): string {
  const d = new Date(ms);
  const z = (n: number, w = 2) => String(n).padStart(w, '0');
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], mons = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const f: Record<string, () => string> = {
    Y: () => String(d.getUTCFullYear()), y: () => z(d.getUTCFullYear() % 100), m: () => z(d.getUTCMonth() + 1), d: () => z(d.getUTCDate()), e: () => String(d.getUTCDate()).padStart(2, ' '),
    H: () => z(d.getUTCHours()), M: () => z(d.getUTCMinutes()), S: () => z(d.getUTCSeconds()), s: () => String(Math.floor(ms / 1000)), N: () => z(d.getUTCMilliseconds() * 1e6, 9),
    F: () => `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}`, T: () => `${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}`,
    Z: () => 'UTC', z: () => '+0000', a: () => days[d.getUTCDay()], b: () => mons[d.getUTCMonth()], '%': () => '%',
  };
  return fmt.replace(/%(\d?)([A-Za-z%])/g, (m, w, c) => (f[c] ? (c === 'N' && w ? f[c]().slice(0, Number(w)) : f[c]()) : m));
}
registerCommand('date', (a) => {
  let ms = now();
  let fmt: string | undefined;
  for (let i = 0; i < a.length; i++) {
    if (a[i] === '-d' || a[i] === '--date') {
      const v = parseDateArg(a[++i] ?? '', ms);
      if (v === null) return fail(`date: invalid date '${a[i]}'`);
      ms = v;
    } else if (a[i].startsWith('--date=')) {
      const v = parseDateArg(a[i].slice(7), ms);
      if (v === null) return fail(`date: invalid date '${a[i].slice(7)}'`);
      ms = v;
    } else if (a[i].startsWith('+')) fmt = a[i].slice(1);
    else if (a[i] === '-u' || a[i] === '--utc') continue;
  }
  if (fmt !== undefined) return ok(strftime(fmt, ms) + '\n');
  if (a.includes('-u')) return ok(strftime('%a %b %e %H:%M:%S UTC %Y', ms) + '\n');
  return ok(new Date(ms).toString() + '\n');
});

registerCommand('cd', (a, { sh }) => {
  const target = a[0] ?? sh.vars.HOME ?? `/home/${sh.s.me.userName}`;
  const p = abs(sh, target === '~' ? `/home/${sh.s.me.userName}` : target.replace(/^~\//, `/home/${sh.s.me.userName}/`));
  if (!sh.fs.exists(p)) return fail(`bash: cd: ${target}: No such file or directory`);
  if (!sh.fs.isDir(p)) return fail(`bash: cd: ${target}: Not a directory`);
  sh.cwd = p;
  return ok();
});

registerCommand('ls', (args, { sh }) => {
  const { flags, rest } = splitFlags(args);
  const targets = rest.length ? rest : ['.'];
  let out = '';
  for (const t of targets) {
    const p = abs(sh, t);
    if (!sh.fs.exists(p)) return fail(`ls: cannot access '${t}': No such file or directory`, 2);
    let names = sh.fs.list(p);
    if (!flags.has('a') && !flags.has('A')) names = names.filter((n) => !n.startsWith('.'));
    if (targets.length > 1) out += `${t}:\n`;
    if (flags.has('l')) {
      for (const n of names) {
        const st = sh.fs.stat(sh.fs.isDir(p) ? VFS.norm(n, p) : p)!;
        out += `${st.type === 'dir' ? 'drwxr-xr-x' : '-rw-r--r--'} 1 ${sh.s.me.userName} ${sh.s.me.userName} ${String(st.size).padStart(6)} Nov  7 12:00 ${n}${st.type === 'dir' && flags.has('F') ? '/' : ''}\n`;
      }
    } else out += names.join('\n') + (names.length ? '\n' : '');
  }
  return ok(out);
});

registerCommand('mkdir', (args, { sh }) => {
  const { flags, rest } = splitFlags(args);
  for (const r of rest) {
    try {
      if (!flags.has('p') && sh.fs.exists(abs(sh, r))) return fail(`mkdir: cannot create directory '${r}': File exists`);
      sh.fs.mkdir(abs(sh, r), flags.has('p'));
    } catch (e) {
      return fail(`mkdir: cannot create directory '${r}': ${(e as Error).message}`);
    }
  }
  return ok();
});

registerCommand('touch', (args, { sh }) => {
  for (const r of args) {
    const p = abs(sh, r);
    if (!sh.fs.exists(p)) sh.fs.writeFile(p, '');
  }
  return ok();
});

registerCommand('rm', (args, { sh }) => {
  const { flags, rest } = splitFlags(args);
  for (const r of rest) {
    try {
      if (!sh.fs.exists(abs(sh, r))) {
        if (flags.has('f')) continue;
        return fail(`rm: cannot remove '${r}': No such file or directory`);
      }
      if (sh.fs.isDir(abs(sh, r)) && !(flags.has('r') || flags.has('R'))) return fail(`rm: cannot remove '${r}': Is a directory`);
      sh.fs.remove(abs(sh, r), true);
    } catch (e) {
      return fail(`rm: ${(e as Error).message}`);
    }
  }
  return ok();
});

registerCommand('cp', (args, { sh }) => {
  const { rest } = splitFlags(args);
  if (rest.length < 2) return fail('cp: missing destination file operand');
  const dst = abs(sh, rest[rest.length - 1]);
  for (const s of rest.slice(0, -1)) {
    const src = abs(sh, s);
    if (!sh.fs.exists(src)) return fail(`cp: cannot stat '${s}': No such file or directory`);
    sh.fs.copy(src, sh.fs.isDir(dst) ? VFS.norm(s.split('/').pop()!, dst) : dst);
  }
  return ok();
});
registerCommand('mv', (args, { sh }) => {
  const { rest } = splitFlags(args);
  if (rest.length < 2) return fail('mv: missing destination file operand');
  const dst = abs(sh, rest[rest.length - 1]);
  for (const s of rest.slice(0, -1)) {
    const src = abs(sh, s);
    if (!sh.fs.exists(src)) return fail(`mv: cannot stat '${s}': No such file or directory`);
    sh.fs.copy(src, sh.fs.isDir(dst) ? VFS.norm(s.split('/').pop()!, dst) : dst);
    sh.fs.remove(src, true);
  }
  return ok();
});

registerCommand('cat', (args, { sh, stdin }) => {
  const r = readInputs(sh, args.filter((a) => a !== '-'), stdin);
  return 'err' in r ? fail(`cat: ${r.err}`) : ok(r.text);
});

registerCommand('tee', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args);
  for (const f of rest) sh.fs.writeFile(abs(sh, f), stdin, flags.has('a'));
  return ok(stdin);
});

const lines = (t: string) => (t === '' ? [] : t.replace(/\n$/, '').split('\n'));
const join = (l: string[]) => (l.length ? l.join('\n') + '\n' : '');

registerCommand('head', (args, { sh, stdin }) => {
  let n = 10;
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-n') n = Number(args[++i]);
    else if (/^-\d+$/.test(args[i])) n = Number(args[i].slice(1));
    else files.push(args[i]);
  }
  const r = readInputs(sh, files, stdin);
  return 'err' in r ? fail(`head: ${r.err}`) : ok(join(lines(r.text).slice(0, n)));
});
registerCommand('tail', (args, { sh, stdin }) => {
  let n = 10;
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-n') n = Number(args[++i]);
    else if (/^-\d+$/.test(args[i])) n = Number(args[i].slice(1));
    else files.push(args[i]);
  }
  const r = readInputs(sh, files, stdin);
  return 'err' in r ? fail(`tail: ${r.err}`) : ok(join(lines(r.text).slice(-n)));
});
registerCommand('wc', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args);
  const r = readInputs(sh, rest, stdin);
  if ('err' in r) return fail(`wc: ${r.err}`);
  const l = lines(r.text).length;
  const w = r.text.split(/\s+/).filter(Boolean).length;
  if (flags.has('l')) return ok(`${l}\n`);
  if (flags.has('w')) return ok(`${w}\n`);
  if (flags.has('c')) return ok(`${r.text.length}\n`);
  return ok(`${l} ${w} ${r.text.length}\n`);
});
registerCommand('sort', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args);
  const r = readInputs(sh, rest, stdin);
  if ('err' in r) return fail(`sort: ${r.err}`);
  let l = lines(r.text).sort((a, b) => (flags.has('n') ? Number(a) - Number(b) : a < b ? -1 : a > b ? 1 : 0));
  if (flags.has('r')) l = l.reverse();
  if (flags.has('u')) l = [...new Set(l)];
  return ok(join(l));
});
registerCommand('uniq', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args);
  const r = readInputs(sh, rest, stdin);
  if ('err' in r) return fail(`uniq: ${r.err}`);
  const out: string[] = [];
  let prev: string | null = null;
  let count = 0;
  const flush = () => prev !== null && out.push(flags.has('c') ? `${String(count).padStart(7)} ${prev}` : prev);
  for (const l of lines(r.text)) {
    if (l === prev) count++;
    else {
      flush();
      prev = l;
      count = 1;
    }
  }
  flush();
  return ok(join(out));
});
registerCommand('cut', (args, { sh, stdin }) => {
  let d = '\t';
  let f = '1';
  const files: string[] = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('-d')) d = args[i].length > 2 ? args[i].slice(2) : args[++i];
    else if (args[i].startsWith('-f')) f = args[i].length > 2 ? args[i].slice(2) : args[++i];
    else files.push(args[i]);
  }
  const r = readInputs(sh, files, stdin);
  if ('err' in r) return fail(`cut: ${r.err}`);
  const idx = f.split(',').map((x) => Number(x) - 1);
  return ok(join(lines(r.text).map((l) => idx.map((i) => l.split(d)[i] ?? '').join(d))));
});
registerCommand('tr', (args, { stdin }) => {
  const { flags, rest } = splitFlags(args);
  if (flags.has('d')) return ok(stdin.replace(new RegExp(`[${rest[0]}]`, 'g'), ''));
  const expand = (s: string) => s.replace(/([a-zA-Z0-9])-([a-zA-Z0-9])/g, (_, a, b) => Array.from({ length: b.charCodeAt(0) - a.charCodeAt(0) + 1 }, (_x, i) => String.fromCharCode(a.charCodeAt(0) + i)).join(''));
  const from = expand(rest[0] ?? '');
  const to = expand(rest[1] ?? '');
  return ok([...stdin].map((c) => { const i = from.indexOf(c); return i < 0 ? c : to[Math.min(i, to.length - 1)] ?? c; }).join(''));
});
registerCommand('grep', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args.filter((a) => !a.startsWith('--color')));
  const [pat, ...files] = rest;
  if (pat === undefined) return fail('Usage: grep [OPTION]... PATTERNS [FILE]...', 2);
  const r = readInputs(sh, files, stdin);
  if ('err' in r) return fail(`grep: ${r.err}`, 2);
  let re: RegExp;
  try {
    re = new RegExp(flags.has('F') ? pat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : pat, flags.has('i') ? 'i' : '');
  } catch {
    return fail('grep: Invalid regular expression', 2);
  }
  const matched = lines(r.text).map((l, i) => ({ l, i })).filter(({ l }) => re.test(l) !== flags.has('v'));
  if (flags.has('c')) return { out: matched.length + '\n', err: '', code: matched.length ? 0 : 1 };
  if (flags.has('q')) return { out: '', err: '', code: matched.length ? 0 : 1 };
  return { out: join(matched.map(({ l, i }) => (flags.has('n') ? `${i + 1}:${l}` : l))), err: '', code: matched.length ? 0 : 1 };
});
registerCommand('sed', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args.filter((a) => a !== '-e'));
  const [expr, ...files] = rest;
  const m = /^s(.)(.*?)\1(.*?)\1([gi]*)$/.exec(expr ?? '');
  if (!m) return fail('sed: only s/// expressions are supported');
  const r = readInputs(sh, files, stdin);
  if ('err' in r) return fail(`sed: ${r.err}`);
  const re = new RegExp(m[2], m[4]);
  const out = r.text.split('\n').map((l) => l.replace(re, m[3])).join('\n');
  if (flags.has('i') && files.length) {
    sh.fs.writeFile(abs(sh, files[0]), out);
    return ok();
  }
  return ok(out);
});
registerCommand('basename', (a) => ok((a[0] ?? '').split('/').filter(Boolean).pop() + '\n'));
registerCommand('dirname', (a) => ok((a[0] ?? '').split('/').slice(0, -1).join('/') || '.' + '\n'));
registerCommand('seq', (a) => {
  const [s, e] = a.length === 1 ? [1, Number(a[0])] : [Number(a[0]), Number(a[1])];
  return ok(join(Array.from({ length: Math.max(0, e - s + 1) }, (_, i) => String(s + i))));
});
const utf8ToB64 = (s: string) => btoa(String.fromCharCode(...new TextEncoder().encode(s)));
const b64ToUtf8 = (s: string) => new TextDecoder().decode(Uint8Array.from(atob(s), (c) => c.charCodeAt(0)));
registerCommand('base64', (a, { stdin }) => {
  try {
    if (a.includes('-d') || a.includes('--decode')) return ok(b64ToUtf8(stdin.trim()));
    return ok(utf8ToB64(stdin) + '\n');
  } catch {
    return fail('base64: invalid input');
  }
});
registerCommand('xargs', async (args, { sh, stdin }) => {
  const words = stdin.split(/\s+/).filter(Boolean);
  const cmd = args.join(' ') || 'echo';
  return runString(sh, `${cmd} ${words.map((w) => `'${w}'`).join(' ')}`);
});

registerCommand('env', (_a, { sh }) => ok(Object.entries({ ...sh.s.cli.env, ...sh.vars }).map(([k, v]) => `${k}=${v}`).join('\n') + '\n'));
registerCommand('export', (args, { sh }) => {
  for (const a of args) {
    const eq = a.indexOf('=');
    if (eq > 0) {
      sh.vars[a.slice(0, eq)] = a.slice(eq + 1);
      sh.s.cli.env[a.slice(0, eq)] = a.slice(eq + 1);
    } else if (sh.vars[a] !== undefined) sh.s.cli.env[a] = sh.vars[a];
  }
  return ok();
});
registerCommand('unset', (args, { sh }) => {
  for (const a of args) {
    delete sh.vars[a];
    delete sh.s.cli.env[a];
  }
  return ok();
});
registerCommand('history', (_a, { sh }) => ok(sh.s.cli.history.map((h, i) => `${String(i + 1).padStart(5)}  ${h}`).join('\n') + '\n'));
registerCommand('which', (a) => ok(a.map((x) => `/usr/local/bin/${x}`).join('\n') + '\n'));

function testExpr(sh: Shell, a: string[]): boolean {
  if (a[0] === '!') return !testExpr(sh, a.slice(1));
  if (a.length === 1) return a[0] !== '';
  if (a.length === 2) {
    const [op, v] = a;
    if (op === '-z') return v === '';
    if (op === '-n') return v !== '';
    if (op === '-f') return sh.fs.isFile(abs(sh, v));
    if (op === '-d') return sh.fs.isDir(abs(sh, v));
    if (op === '-e') return sh.fs.exists(abs(sh, v));
    if (op === '-s') return sh.fs.isFile(abs(sh, v)) && sh.fs.readFile(abs(sh, v)).length > 0;
  }
  if (a.length === 3) {
    const [l, op, r] = a;
    if (op === '=' || op === '==') return l === r;
    if (op === '!=') return l !== r;
    if (op === '-eq') return Number(l) === Number(r);
    if (op === '-ne') return Number(l) !== Number(r);
    if (op === '-gt') return Number(l) > Number(r);
    if (op === '-lt') return Number(l) < Number(r);
    if (op === '-ge') return Number(l) >= Number(r);
    if (op === '-le') return Number(l) <= Number(r);
  }
  return false;
}
registerCommand('test', (a, { sh }) => ({ out: '', err: '', code: testExpr(sh, a) ? 0 : 1 }));
registerCommand('[', (a, { sh }) => ({ out: '', err: '', code: testExpr(sh, a.filter((x) => x !== ']')) ? 0 : 1 }));
registerCommand('[[', (a, { sh }) => ({ out: '', err: '', code: testExpr(sh, a.filter((x) => x !== ']]')) ? 0 : 1 }));

// ---------------------------------------------------------------- jq

registerCommand('jq', (args, { sh, stdin }) => {
  const { flags, rest } = splitFlags(args);
  const [prog = '.', ...files] = rest;
  const r = readInputs(sh, files, stdin);
  if ('err' in r) return fail(`jq: error: Could not open ${r.err}`, 2);
  let input: any;
  try {
    input = JSON.parse(r.text);
  } catch {
    return fail('jq: error (at <stdin>:0): Cannot parse input as JSON', 2);
  }
  try {
    const res = runJq(prog, input);
    const fmt = (v: any) => (flags.has('r') && typeof v === 'string' ? v : flags.has('c') ? JSON.stringify(v) : JSON.stringify(v, null, 2));
    return ok(res.map(fmt).join('\n') + (res.length ? '\n' : ''));
  } catch (e) {
    if (e instanceof JqError) return fail(`jq: error: ${e.message}`, 3);
    return fail(`jq: error: ${(e as Error).message}`, 5);
  }
});

// ---------------------------------------------------------------- curl (solo S3 y direcciones públicas simuladas)

export function s3Target(url: string): { bucket: string; key: string; website: boolean } | null {
  const u = /^https?:\/\/([^/]+)(\/.*)?$/.exec(url);
  if (!u) return null;
  const host = u[1];
  const path = (u[2] ?? '/').slice(1).split('?')[0];
  let m = /^(.+)\.s3-website[.-]([a-z0-9-]+)\.amazonaws\.com$/.exec(host);
  if (m) return { bucket: m[1], key: decodeURIComponent(path), website: true };
  m = /^(.+)\.s3[.-]([a-z0-9-]+)\.amazonaws\.com$/.exec(host) ?? /^(.+)\.s3\.amazonaws\.com$/.exec(host);
  if (m) return { bucket: m[1], key: decodeURIComponent(path), website: false };
  m = /^s3[.-]([a-z0-9-]+)\.amazonaws\.com$/.exec(host);
  if (m) {
    const [b, ...k] = path.split('/');
    return { bucket: b, key: decodeURIComponent(k.join('/')), website: false };
  }
  return null;
}

registerCommand('curl', (args, { sh }): CmdResult => {
  const { flags, rest } = splitFlags(args.filter((a, i) => !(args[i - 1] === '-o' || args[i - 1] === '-H')));
  const bare = rest.find((a) => /^(localhost|[\w-]+(\.[\w-]+)+|\d+\.\d+\.\d+\.\d+)(:\d+)?(\/.*)?$/.test(a));
  const url = rest.find((a) => /^https?:\/\//.test(a)) ?? (bare ? 'http://' + bare : undefined);
  if (!url) return fail('curl: no URL specified', 2);
  const t = s3Target(url);
  let r: { status: number; contentType: string; body: string };
  if (!t) {
    const w = webGet(sh.s, url);
    if (!w || w.kind === 'nohost') return fail(`curl: (6) Could not resolve host: ${url.split('/')[2].split(':')[0]}`, 6);
    if (w.kind === 'refused') return fail(`curl: (7) Failed to connect to ${w.host} port ${w.port} after 1 ms: Connection refused`, 7);
    if (w.kind === 'timeout') return fail(`curl: (28) Failed to connect to ${w.host} port ${w.port} after 130102 ms: Connection timed out`, 28);
    if (w.kind === 'ssl') return fail(`curl: (35) OpenSSL SSL_connect: SSL_ERROR_SYSCALL in connection to ${w.host}:${w.port} `, 35);
    if (w.kind !== 'ok') return fail('curl: (56) Failure', 56);
    r = { status: w.status, contentType: w.headers['content-type'], body: w.body };
  } else {
    const qs = url.includes('?') ? new URLSearchParams(url.slice(url.indexOf('?') + 1)) : null;
    r = qs?.has('X-Amz-Signature') ? presignedGet(sh.s, t.bucket, t.key, qs) : anonymousGet(sh.s, t.bucket, t.key, t.website);
  }
  const oIdx = args.indexOf('-o');
  if (flags.has('I') || flags.has('head')) return ok(`HTTP/1.1 ${r.status}\ncontent-type: ${r.contentType}\n\n`);
  if (r.status >= 400 && (flags.has('f') || flags.has('fail'))) return fail(`curl: (22) The requested URL returned error: ${r.status}`, 22);
  if (flags.has('w')) return ok(String(r.status));
  if (oIdx >= 0) {
    sh.fs.writeFile(abs(sh, args[oIdx + 1]), r.body);
    return ok();
  }
  return ok(r.body + (r.body.endsWith('\n') ? '' : '\n'));
});
