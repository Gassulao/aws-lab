import React from 'react';

// Iconos propios (trazo simple, sin logotipos reales de AWS). Cada servicio usa un glifo en una rejilla de 24x24.
const G: Record<string, React.ReactNode> = {
  ec2: <><rect x="4" y="4" width="16" height="6" rx="1" /><rect x="4" y="14" width="16" height="6" rx="1" /><path d="M7.5 7h.01M7.5 17h.01M12 7h5M12 17h5" /></>,
  iam: <><path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6z" /><circle cx="12" cy="10" r="2" /><path d="M12 12v4" /></>,
  s3: <><path d="M5 7c0-1.7 3.1-3 7-3s7 1.3 7 3-3.1 3-7 3-7-1.3-7-3z" /><path d="M5 7l1.5 11c.2 1.2 2.8 2 5.5 2s5.3-.8 5.5-2L19 7" /></>,
  vpc: <><path d="M7 18a4 4 0 0 1-.6-7.9A5.5 5.5 0 0 1 17 9a3.5 3.5 0 0 1 .5 7" /><path d="M12 13v7M9 20h6M8 16h8" /></>,
  cloudtrail: <><path d="M4 5h16v14H4z" /><path d="M8 9h8M8 12h8M8 15h5" /></>,
  academy: <><path d="m2.5 9 9.5-4.5L21.5 9 12 13.5z" /><path d="M6 11.5V16c0 1.2 2.7 2.5 6 2.5s6-1.3 6-2.5v-4.5M21.5 9v5" /></>,
  cloudshell: <><rect x="3" y="4" width="18" height="16" rx="1.5" /><path d="m7 9 3 3-3 3M12.5 15H17" /></>,
  default: <><circle cx="12" cy="12" r="8" /><path d="M12 8v4l3 2" /></>,
};

export function ServiceIcon({ id, color, size = 32 }: { id: string; color: string; size?: number }) {
  return (
    <span className="hm-ico" style={{ background: color, width: size, height: size }} aria-hidden="true">
      <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{G[id] ?? G.default}</svg>
    </span>
  );
}
