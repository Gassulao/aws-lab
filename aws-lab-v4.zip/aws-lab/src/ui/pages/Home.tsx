import React, { useEffect, useState } from 'react';
import { useCloud } from '../session';
import { CATEGORIES, SERVICES, svcOf } from '../services';
import { Btn, Card, Modal, PageHead, nav } from '../components/ui';
import { mutate } from '../../engine/store';
import { settle } from '../../engine/services/ec2';
import { ServiceIcon } from './home/icons';
import { estimateCost, usd } from './home/cost';
import './home/home.css';

// ---------------------------------------------------------------- «Visitado recientemente»
// Se registra cada servicio al que se navega (escucha global del hash); queda en `s.recent` y se guarda con el estado.
const SHELL = { id: 'cloudshell', name: 'CloudShell', color: '#232f3e', desc: 'Terminal de línea de comandos en el navegador', home: '/cloudshell' };
const idOfHash = (): string | null => {
  const p = '/' + location.hash.replace(/^#\/?/, '').split('?')[0];
  if (p === '/cloudshell' || p.startsWith('/cloudshell/')) return 'cloudshell';
  return svcOf(p)?.id ?? null;
};
function recordVisit() {
  const id = idOfHash();
  if (!id) return;
  mutate((s) => {
    if (s.recent?.[0] === id) return;
    s.recent = [id, ...(s.recent ?? []).filter((x) => x !== id)].slice(0, 8);
  });
}
if (typeof window !== 'undefined') {
  addEventListener('hashchange', recordVisit);
  setTimeout(recordVisit, 1500);
}

const entry = (id: string) => (id === 'cloudshell' ? SHELL : SERVICES.find((x) => x.id === id));

export function Home() {
  const s = useCloud();
  settle(s);
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 5000);
    return () => clearInterval(t);
  }, []);
  const [cat, setCat] = useState('Todos');
  const [appModal, setAppModal] = useState(false);
  const cost = estimateCost(s);
  const recent = (s.recent ?? []).map(entry).filter(Boolean) as { id: string; name: string; color: string; desc: string; home: string }[];
  const all = cat === 'Todos' ? SERVICES : SERVICES.filter((x) => x.cat === cat);
  const monthName = new Date().toLocaleString('es-ES', { month: 'long', year: 'numeric' });
  const go = (to: string) => (e: React.MouseEvent) => { e.preventDefault(); nav(to); };

  return (
    <>
      <PageHead title="Consola de administración de AWS" desc={`Bienvenido, ${s.settings.userDisplayName}. Cuenta ${s.account.id}.`} />
      <div className="hm-cols">
        <div>
          <Card title="Visitado recientemente" actions={<a href="#all-services" onClick={(e) => { e.preventDefault(); document.getElementById('all-services')?.scrollIntoView({ behavior: 'smooth' }); }}>Ver todos los servicios</a>}>
            {recent.length === 0 ? (
              <div className="hm-empty"><b>Aún no ha visitado ningún servicio</b>Los servicios que abra aparecerán aquí.</div>
            ) : (
              <div className="hm-list">
                {recent.map((x) => (
                  <a key={x.id} className="hm-row" href={'#' + x.home} onClick={go(x.home)}>
                    <ServiceIcon id={x.id} color={x.color} />
                    <div><b>{x.name}</b><small>{x.desc}</small></div>
                  </a>
                ))}
              </div>
            )}
          </Card>
          <Card title="Aplicaciones" count={0} actions={<Btn onClick={() => setAppModal(true)}>Crear aplicación</Btn>}>
            <div className="hm-muted" style={{ marginBottom: 6 }}>Región: {s.region}</div>
            <div className="hm-empty"><b>No hay aplicaciones</b>Las aplicaciones agrupan los recursos de una carga de trabajo para administrarlos juntos.</div>
          </Card>
          <div id="all-services">
            <Card title="Todos los servicios" count={all.length}>
              <div className="hm-chips">
                {['Todos', ...CATEGORIES].map((c) => <button key={c} className={c === cat ? 'on' : ''} onClick={() => setCat(c)}>{c}</button>)}
              </div>
              <div className="hm-grid">
                {all.map((x) => (
                  <a key={x.id} className="hm-tile" href={'#' + x.home} onClick={go(x.home)}>
                    <ServiceIcon id={x.id} color={x.color} />
                    <div><b>{x.name}</b><small>{x.desc}</small></div>
                  </a>
                ))}
                {(cat === 'Todos' || cat === 'Administración y gobernanza') && (
                  <a className="hm-tile" href="#/cloudshell" onClick={go('/cloudshell')}>
                    <ServiceIcon id="cloudshell" color={SHELL.color} />
                    <div><b>CloudShell</b><small>{SHELL.desc}</small></div>
                  </a>
                )}
              </div>
              {all.length === 0 && <div className="hm-empty">No hay servicios en esta categoría.</div>}
            </Card>
          </div>
        </div>
        <div>
          <Card title="Bienvenido a AWS">
            <div className="hm-links">
              <a href="#/academy" onClick={go('/academy')}>Introducción a AWS<small>Laboratorios guiados por niveles en la Academia</small></a>
              <a href="#/cloudshell" onClick={go('/cloudshell')}>Pruebe el AWS CLI en CloudShell<small>Terminal ya autenticada con su usuario</small></a>
              <a href="https://aws.amazon.com/es/training/" target="_blank" rel="noreferrer">Formación y certificación<small>Aprenda de los expertos y obtenga una certificación</small></a>
              <a href="https://aws.amazon.com/es/new/" target="_blank" rel="noreferrer">Novedades de AWS<small>Descubra las últimas características y servicios</small></a>
            </div>
          </Card>
          <Card title="Estado de AWS">
            <p style={{ margin: '0 0 6px' }}><span className="status ok">Este servicio funciona con normalidad</span></p>
            <div className="hm-muted">Región {s.region} · sin problemas en curso</div>
            <p style={{ margin: '10px 0 0' }}><a href="https://health.aws.amazon.com/health/status" target="_blank" rel="noreferrer">Ir a AWS Health Dashboard</a></p>
          </Card>
          <Card title="Costos y uso" actions={<span className="hm-muted">Simulado</span>}>
            <div className="hm-muted">Costo del mes hasta la fecha ({monthName})</div>
            <div className="hm-big" aria-label="Costo del mes hasta la fecha">{usd(cost.total)}</div>
            <div className="hm-muted" style={{ marginTop: 4 }}>
              {cost.running} instancia{cost.running === 1 ? '' : 's'} en ejecución · {usd(cost.hourly)}/hora · previsión mensual {usd(cost.monthly)}
            </div>
            <table className="hm-cost"><tbody>{cost.lines.map((l) => <tr key={l.label}><td>{l.label}</td><td>{usd(l.usd)}</td></tr>)}</tbody></table>
            <p style={{ margin: '10px 0 0' }}><a href="#/ec2/instances" onClick={go('/ec2/instances')}>Ver instancias</a></p>
          </Card>
          <Card title="Resumen de la cuenta">
            <div className="kv" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <div><div className="k">Instancias en ejecución</div><div className="v"><a href="#/ec2/instances" onClick={go('/ec2/instances')}>{cost.running}</a></div></div>
              <div><div className="k">Buckets de S3</div><div className="v"><a href="#/s3/buckets" onClick={go('/s3/buckets')}>{s.buckets.length}</a></div></div>
              <div><div className="k">Usuarios de IAM</div><div className="v"><a href="#/iam/users" onClick={go('/iam/users')}>{s.users.length}</a></div></div>
              <div><div className="k">VPC (región actual)</div><div className="v"><a href="#/vpc/vpcs" onClick={go('/vpc/vpcs')}>{s.vpcs.filter((v) => v.region === s.region).length}</a></div></div>
              <div><div className="k">Región</div><div className="v">{s.region}</div></div>
              <div><div className="k">Eventos en CloudTrail</div><div className="v"><a href="#/cloudtrail/events" onClick={go('/cloudtrail/events')}>{s.trail.length}</a></div></div>
            </div>
          </Card>
        </div>
      </div>
      {appModal && (
        <Modal title="Crear aplicación" onClose={() => setAppModal(false)} footer={<><Btn onClick={() => setAppModal(false)}>Cerrar</Btn><Btn kind="primary" onClick={() => { setAppModal(false); nav('/academy'); }}>Ir a la Academia</Btn></>}>
          <p style={{ marginTop: 0 }}>La gestión de aplicaciones no está disponible en este simulador. Puede practicar la organización de recursos con etiquetas (por ejemplo, <code>Name</code>) en VPC y EC2 desde la Academia.</p>
        </Modal>
      )}
    </>
  );
}
